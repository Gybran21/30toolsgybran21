import os
from time import sleep


a ='\033[92m'
b ='\033[91m'
c ='\033[0m'
os.system('clear')
print(a+'\t  TAMBAH TOMBOL TERMUX')
print(b+'\t    VALDER CYBER')
print('\t     FAN VALDER')
print(a+'+'*40)
print('\nProses..')
sleep(1)
print(b+'\n[!] LOADING........')
sleep(1)
try:
      os.mkdir('/data/data/com.termux/files/home/.termux')
except:
      pass
print(a+'[!]Success !')
sleep(1)
print(b+'\n[!] LOAD SYSTEM.... !')
sleep(1)

key = "extra-keys = [['ESC','/','-','HOME','UP','END','PGUP'],['TAB','CTRL','ALT','LEFT','DOWN','RIGHT','PGDN']]"
kontol = open('/data/data/com.termux/files/home/.termux/termux.properties','w')
kontol.write(key)
kontol.close()
sleep(1)
print(a+'[!] Succsess !')
sleep(1)
print(b+'\n[!] Setting up..')
sleep(2)
os.system('termux-reload-settings')
print(a+'[!] Successfully !!! '+c+'\n\nSUBSCRIBE\nYOUTUBE : FAN VALDER\n\n')


