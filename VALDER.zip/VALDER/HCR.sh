#!/bin/sh
#Version 1.0
#MAU APA BANG..?
#MAU REEDIT? RECOPYRIGHT?
#SILAHKAN KALAU MAU REEDIT
#CHAT AJA BANG 087744768614


bi='\033[34;1m' #biru
i='\033[32;1m' #ijo
pur='\033[35;1m' #purple
cy='\033[36;1m' #cyan
me='\033[31;1m' #merah
pu='\033[37;1m' #putih
ku='\033[33;1m' #kuning
clear

cd 0909
cd 0808
python2 000.py
clear
cd /sdcard/VALDER
sh 222.sh
clear

#FANFALDERCYBER
echo "$i╔════════════════════════════════════════╗"
echo "$i║$pur           TOOLS$i           ║$pur   STATUS$i   ║"
echo "$i╚════════════════════════════════════════╝"
echo "╔════════════════════════════════════════╗"
echo "║01║SPAM                    ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║02║BRUTEFORCE              ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║03║TOMBOL TERMUX           ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║04║INSTAL TOOLS TUAN B4DUT ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║05║SCRIPT DEVACE           ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║06║SCRIPT DEVACE$cy v.2$i       ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║07║HACK FACEBOOK           ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║08║SMS GRATIS ALL          ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║09║HACK CCTV               ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║10║INSTALL METASPLOIT      ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║11║LOCATOR                 ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║12║HACK KAMERA DEPAN       ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║13║HACK FACEBOOK MASAL     ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║14║SPAM INSTAGRAM          ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║15║SPAM WHATSAPP           ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║16║SPAM SMS                ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║17║HACK FACEBOOK$cy v.2$i       ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║18║HACK FACEBOOK$me v.root$i    ║$me    ROOT$i    ║"
echo "║══║════════════════════════║════════════║"
echo "║19║HACK INSTAGRAM$me v.root$i   ║$me    ROOT$i    ║"
echo "║══║════════════════════════║════════════║"
echo "║20║HACK TWITTER$me v.root$i     ║$me    ROOT$i    ║"
echo "║══║════════════════════════║════════════║"
echo "║21║HACK GMAIL$me v.root$i       ║$me    ROOT$i    ║"
echo "║══║════════════════════════║════════════║"
echo "║22║FACEBOOK INFO           ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║23║SANTET ONLINE           ║$bi   NO ROOT$i  ║"
echo "║═══════════════════════════║════════════║"
echo "║24║TEMBAK KUOTA XL         ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║25║YOUTUBE AUTOVIEW        ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║26║PHISING$cy v.1$i             ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║27║PHISING$cy v.2$i             ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║28║PHISING$cy v.3$i             ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║29║PHISING$cy v.4$i             ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "║30║PHISING GAMES           ║$bi   NO ROOT$i  ║"
echo "║══║════════════════════════║════════════║"
echo "╚══╚════════════════════════╝════════════╝"
echo "$bi     ╚═══$cy[$me♦$cy] FAN VALDER CYBER [$me♦$cy]$bi═══╝"
echo
echo "$pur══════════════════╗$pu"
read -p "PILIHAN ANDA      : " valder
if [ $valder -eq 1 ]
then
sh spamvalder.sh

elif [ $valder -eq 2 ]
then
cd 3571
sh fan.sh

elif [ $valder -eq 3 ]
then
cd 770
python2 770.py

elif [ $valder -eq 4 ]
then
apt update && apt upgrade 
pkg install python python2 vim figlet curl 
pkg install php 
pip2 install lolcat 
pkg install git 
git clone https://github.com/TUANB4DUT/TOOLSINSTALLERv3
cd TOOLSINSTALLERv3 
chmod +x TUANB4DUT.sh 
sh TUANB4DUT.sh

elif [ $valder -eq 5 ]
then
python2 creator.py

elif [ $valder -eq 6 ]
then
python2 LITESCRIPT.py

elif [ $valder -eq 7 ]
then
python2 hack.py

elif [ $valder -eq 8 ]
then
python sms.py

elif [ $valder -eq 9 ]
then
clear
git clone http://github.com/kancotdiq/ipcs
cd ipcs
python2 scan.py

elif [ $valder -eq 10 ]
then
apt update && apt upgrade
apt install git
apt install wget
wget https://raw.githubusercontent.com/verluchie/termux-metasploit/master/install.sh
chmod 777 install.sh
sh install.sh

elif [ $valder -eq 11 ]
then
cd ghyt
bash locator.sh

elif [ $valder -eq 12 ]
then
cd saycheese
bash saycheese.sh

elif [ $valder -eq 13 ]
then
pip2 install --upgrade pip
git clone https://github.com/Senitopeng/fbbrute.git
cd fbbrute
python2 jomblo.py

elif [ $valder -eq 14 ]
then
apt update
apt upgrade
apt install git
git clone https://github.com/thelinuxchoise/instaspam.git
ls
cd instaspam
bash instaspam.sh

elif [ $valder -eq 15 ]
then
apt update -y
apt upgrade -y
apt install git
apt install php
git clone https:// github.com/siputra12/prank
cd prank
ls
php wa.php

elif [ $valder -eq 16 ]
then
pip2 install requests
apt install nano
apt install git
git clone https://github.comSenitopeng/SpamSms.git
cd SpamSms
chmod +× mantan.py
python2 mantan.py

elif [ $valder -eq 17 ]
then
pip2 install --upgrade pip
pip2 install mechanize
pip2 install requests
apt install git
git clone https://github.com/Senitopeng/KumpulanFbbrute.git
cd KumpulanFbbrute
python2 jomblo.py

elif [ $valder -eq 18 ]
then
apt update && apt upgrade
gt clone https://github.com/thelinuxchoise/facebash.git
cd facebash
bash facebash.sh
sleep1
echo "[!]ANDA HARUS MENGGUNAKAN AKSES ROOT"

elif [ $valder -eq 19 ]
then
git clone https://github.com/thelinuxchoise/instashell.git
cd instashell
bash instashell.sh
sleep1
echo "[!] ANDA HARUS MENGGUNAKAN AKSES ROOT"

elif [ $valder -eq 20 ]
then
git clone https://github.com/thelinuxchoise/tweetshell
cd tweetshell
chmod +x tweetshell.sh
bash tweetshell.sh
sleep1
echo "[!]ANDA HARUS MENGGUNAKAN AKSES ROOT"

elif [ $valder -eq 21 ]
then
apt update && apt upgrade
git clone https://github.com/thelinuxchoise/gmailshell.git
cd gmailshell
bash gmailshell.sh
sleep1
echo "[!]ANDA HARUS MENGGUNAKAN AKSES ROOT"

	elif [ $valder -eq 22 ]
	then
	git clone https://github.com/CiKu370/OSIF.git
	cd OSIF
	python2 osif.py

elif [ $valder -eq 23 ]
then
pkg install python
git clone https://github.com/Gameye98/santet-online.git
cd santet-online
python santet.py

	elif [ $valder -eq 24 ]
	then
	pip2 install requests
	apt install python
	apt install git
	pip install requests
	git clone https://github.com/albertoanggi/xl-y.git
	cd xl-py
	python app.py

elif [ $valder -eq 25 ]
then
apt update
apt upgrade
apt install python
apt install git
git clone https://github.com/thelinuxchoise/youbot.git
cd youbot
service tor start
sodo ./youbot.sh URL

	elif [ $valder -eq 26 ]
	then
	apt update
	apt upgrade
	apt install openssh
	apt install curl
	git clone https://github.com/thelinuxchoise/shellphish.git
	cd shellphish
	bash shellphish.sh

elif [ $valder -eq 27 ]
then
apt update
apt upgrade
git clone ://github.com/thelinuxchoise/blackeye.git
cd blackeye.sh
bash blackeye.sh

	elif [ $valder -eq 28 ]
	then
	apt update
	apt upgrade
	git clone ://github.com/UndeadSec/SocialFish.git
	cd SocialFish
	chmod +x *
	pip2 install -r requirements.txt
	python2 SocialFish.py

elif [ $valder -eq 29 ]
then
git clone https://github.com/evait-scurity/weeman.git
chmod +x *
python2 weeman.py

	elif [ $valder -eq 30 ]
	then
	apt update && apt upgrade
	apt install python2
	apt install apache2
	apt install git php unzip
	git clone https://github.com/Senitopeng/Phising0nline.git
	cd Phising0nline
	ls
	unzip Phising0nline.zip
	python2 online.py


else
echo "MAAF PILIHAN ANDA TIDAK TERSEDIA"

	fi







