#!/bin/sh
#Version 1.0
#MAU APA BANG..?
#MAU REEDIT? RECOPYRIGHT?
#SILAHKAN KALAU MAU REEDIT
#CHAT AJA BANG 082372363997


bi='\033[34;1m' #biru
i='\033[32;1m' #ijo
pur='\033[35;1m' #purple
cy='\033[36;1m' #cyan
me='\033[31;1m' #merah
pu='\033[37;1m' #putih
ku='\033[33;1m' #kuning
clear

sh 222.sh

#FANFALDERCYBER
echo "╔════════════════════════════════════════════════════════════════════╗"
echo "║        TOOLS              ║                                        ║"
echo "╚════════════════════════════════════════════════════════════════════╝"
echo "╔════════════════════════════════════════════════════════════════════╗"
echo "║01║SPAM                    ║                                          "
echo "║══║═════════════════════════════════════════════════════════════════"
echo "║02║BRUTEFORCE              ║                                        ║"
echo "║══║══════════════════════════════════════════════════════════════════"
echo "║03║TOMBOL TERMUX           ║                                        ║"
echo "║══║════════════════════════════════════════════════════════════════"
echo "║04║BAGROUND TERMUX         ║                                        ║"
echo "║══║════════════════════════════════════════════════════════════════"
echo "║05║SCRIPT DEVACE           ║                                        ║"
echo "║══║════════════════════════════════════════════════════════════════"
echo "║06║SCRIPT DEVACE v2        ║"
echo "║══║═════════════════════════════════════════════════════════════════"
echo "║07║HACK FACEBOOK           ║"
echo "║══║═════════════════════════════════════════════════════════════════"
echo "║08║SMS GRATIS ALL          ║"
echo "║══║═════════════════════════════════════════════════════════════════"
echo "║09║HACK CCTV               ║"
echo "║══║═════════════════════════════════════════════════════════════════"
echo "║10║INSTALL METASPLOIT     ║"
echo "║══║═════════════════════════════════════════════════════════════════"
echo "║11║LOCATOR                ║"
echo "║══║═════════════════════════════════════════════════════════════════"
echo "║12║HACK KAMERA DEPAN      ║"
echo "║══║═════════════════════════════════════════════════════════════════"
echo "║13║LACAK SOSMED           ║"
echo "║════════════════════════════════════════════════════════════════════"
echo "════════════════════════════════════════════════════════════════════╗"
echo
echo "════════════════════════════════════════════════════════════════════"

read -p "PILIHAN ANDA      : " valder


if [ $valder -eq 1 ]
then
sh spamvalder.sh

	elif [ $valder -eq 2 ]
	then
	cd 3571
	sh fan.sh


		elif [ $valder -eq 3 ]
		then
		cd 770
		python2 770.py

			elif [ $valder -eq 4 ]
			then
			pkg install git

		elif [ $valder -eq 5 ]
		then
		python2 creator.py

	elif [ $valder -eq 6 ]
	then
	python2 LITESCRIPT.py

elif [ $valder -eq 7 ]
then
python2 hack.py

	elif [ $valder -eq 8 ]
	then
	python sms.py

elif [ $valder -eq 9 ]
then
clear
git clone http://github.com/kancotdiq/ipcs
cd ipcs
python2 scan.py

	elif [ $valder -eq 10 ]
	then
	apt update && apt upgrade
	apt install git
	apt install wget
	wget https://raw.githubusercontent.com/verluchie/termux-metasploit/master/install.sh
	chmod 777 install.sh
	sh install.sh

elif [ $valder -eq 11 ]
then
cd ghyt
bash locator.sh

	elif [ $valder -eq 12 ]
	then
	cd saycheese
	bash saycheese.sh

elif [ $valder -eq 13 ]
then
cd userrecon
bash userrecon.sh

	else
	echo "MAAF PILIHAN ANDA TIDAK TERSEDIA"

		fi







