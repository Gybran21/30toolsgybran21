clear
sleep 1
echo "[•]-------------------------------------[•]"
echo " |  SUBSCIBE CHANNEL YOUTUBE FAN VALDER  | "
echo " |    GUNAKAN TOOLS INI DENGAN BIJAK     | "
echo " |           FAN FALDER CYBER            | "
echo "[•]-------------------------------------[•]"
echo "           [•]VAN VALDER CYBER[•]          "
echo "[•]°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°[•]"
echo "Silakan Pilih Spam Yang Tersedia"|lolcat
echo "[1] TELKOMSEL"|lolcat
echo "[2] TOKOPEDIA"|lolcat
echo "[3] JDID"|lolcat
echo "[4] GRAB"|lolcat
echo "[5] PHD"|lolcat
echo ""
echo "[6] Install Bahan"|lolcat
echo "[0] Keluar"|lolcat
echo
echo
echo "Pilih Dan Ketik Nomornya"

echo "Install Bahan Dulu Supaya Gak Gagal Di Nomor 6" |lolcat

read -p "Masukan Nomor Yang Tersedia :" valder

case $valder in
1)
figlet Telkomsel |lolcat
php telkomsel.php
;;
2)
figlet TokoPedia |lolcat
php tokped.php
;;
3)
figlet JDID |lolcat
php jdid.php
;;
4)
figlet GRAB
python2 spammer.py
;;
5)
figlet PHD
php phd.php
;;
6)
clear
sh install.php
sh spamvalder.sh
;;
7)
clear
echo "Berhasil Keluar" |lolcat
echo "Jangan Lupa :" |lolcat
figlet Subscribe |lolcat
figlet FAN VALDER |lolcat
;;
esac
