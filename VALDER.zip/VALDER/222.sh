#!/bin/sh
clear
bi='\033[34;1m' #biru
i='\033[32;1m' #ijo
pur='\033[35;1m' #purple
cy='\033[36;1m' #cyan
me='\033[31;1m' #merah
pu='\033[37;1m' #putih
ku='\033[33;1m' #kuning

echo "[•]-------------------------------------------[•]"
echo "$ku |$pur             SUBSCRIBE FAN VALDER$ku            |"
echo "$ku |---------------------------------------------|"
echo "$ku |$bi AUTHOR   : VALDER CYBER$ku                     |"
echo "$ku |$bi SUPPORT  : YOUTUBE FAN VALDER$ku	       |"
echo "$ku |$bi THANK TO : MR.K7NC8NG$ku		       |"
echo "$ku |$bi VERSION  : 1.0$ku			       |"
echo "$ku |$i     GUNAKAN TOOLS INI DENGAN BIJAK$ku          |"
echo "$ku |$i  DAPATKAN CODE LESENCI SECARA GRATIS DENGAN$ku |"
echo "$ku |$i           HUBUNGI$cy 087744768614$ku              |"
echo "$ku[•]-------------------------------------------[•]"
echo "$pur            [•] FAN VALDER CYBER [•]$ku            "
echo "————————————————————————————————————————————————"


echo "$me╔═════════════════════════════════════╗"
echo "$me║$i Silahkan Bagi Yang Baru Menggunakan$me ║"
echo "$me║$i Tools Ini Di Sarankan Untuk Install$me ║"
echo "$me║$i Bahan2 Nya Dulu Yang Ada Di Bawah$me   ║"
echo "$me║$i Supaya Tidak Error Saat Menjalankan$me ║"
echo "$me║$i Tools Nya Caranya Ketik Saja Angka 1$me║"
echo "$me╚═════════════════════════════════════╝"
echo "$cy       <═══════════════════════>"
echo "$bi╔═════════════════════════════════════╗"
echo "$bi║$i Bagi Yang Sudah Install Bahan2 Nya$bi  ║"
echo "$bi║$i Kalian Langsung Aja Pakai Tools Nya$bi ║"
echo "$bi║$i Caranya Kalian Ketikan Angka 2$bi      ║"
echo "$bi╚═════════════════════════════════════╝"



echo "$bi[$cy 01$bi ]$me INSTALL$cy BAHAN2 NYA"
echo "$bi[$cy 02$bi ]$me MASUK$bi TOOLS NYA"
echo "$bi[$cy 03$bi ]$me UPDATE$cy TOOLS"
echo "$me________________________________"

read -p "[•]Pilih No : " nomer

if [ $nomer -eq 1 ]
then
apt install git
apt install python2
apt install python
apt install git
apt install curl
apt install toilet
pip2 install lolcat
apt install ruby
aot

elif [ $nomer -eq 2 ]
then
clear

elif [ $nomer -eq 3 ]
then
apt update && apt upgrade

else
echo "$me<═════════════════════════════════════>"
echo "$cyMAAF NOMOR YANG ANDA PILIH TIDAK TERSEDIA"

fi
