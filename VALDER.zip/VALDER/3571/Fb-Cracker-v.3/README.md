# Fb-Cracker-v.3
## VERSION 3

# CARA INSTALL
### $ pkg update && pkg upgrade
### $ pkg install git
### $ pkg install python2
### $ pip2 install request
### $ pip2 install mechanize
### $ git clone https://github.com/FR13ND8/Fb-Cracker-v.3
### $ cd Fb-Cracker-v.3
### $ python2 crack.py

# SEKIAN
### FACEBOOK : RISKI DARMAWAN
